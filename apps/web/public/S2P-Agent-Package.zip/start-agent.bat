@echo off
title SOS Print Worker - Shakeel Online Services
echo Starting SOS Print Worker Agent...
cd /d "%~dp0"
if exist "S2P.Agent.Worker.exe" (
    S2P.Agent.Worker.exe
) else (
    echo [ERROR] S2P.Agent.Worker.exe not found!
    pause
)
