# SOS Print Windows Agent — Shakeel Online Services

This agent connects Windows Spooler and installed physical printers to the SOS Print cloud for Shakeel Online Services, Guntur.

## Prerequisites (आवश्यकताएँ)
1. **Operating System:** Windows 10 or Windows 11 (64-bit).
2. **Runtime:** .NET 8.0 Windows Desktop Runtime (x64).
   - Download link: [https://dotnet.microsoft.com/en-us/download/dotnet/8.0](https://dotnet.microsoft.com/en-us/download/dotnet/8.0)
   - Select **.NET Desktop Runtime 8.0.x (Windows x64)**.
3. **Physical Printers:** Ensure printers are installed with manufacturer drivers and set up in Windows Settings → Printers & Scanners.

---

## How to Install and Run (इंस्टॉलेशन और चलाने का तरीका)
1. Unzip this package into a folder on your shop computer.
2. Run **`install-agent.bat`** (यह आवश्यक फाइल्स को चेक और कॉपी करेगा).
3. Run **`start-agent.bat`** (Agent चालू होगा).
4. **Pairing Code (पेयरिंग कोड):**
   - Open your Owner Dashboard at: `http://localhost:3000/dashboard/printers` (या Vercel production URL).
   - Click **"Generate Pairing Code"** (6-digit code).
   - Enter the pairing code in the agent window when prompted.
5. Once paired, the agent will discover your Windows printers and show "ONLINE" in the Dashboard.

---

## How to Uninstall (हटाने का तरीका)
- Run **`uninstall-agent.bat`** to safely stop the process and remove local cached session files.
