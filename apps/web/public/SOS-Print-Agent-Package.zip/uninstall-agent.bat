@echo off
echo ============================================================
echo   SOS Print Windows Agent - Uninstall
echo ============================================================
echo.
echo Stopping running agent processes...
taskkill /f /im S2P.Agent.Worker.exe >nul 2>&1

set TARGET_DIR=%LOCALAPPDATA%\SOSPrintAgent
if exist "%TARGET_DIR%" (
    echo Removing cached files and configuration at %TARGET_DIR%...
    rmdir /s /q "%TARGET_DIR%"
)

echo [SUCCESS] Agent uninstalled cleanly.
pause
