@echo off
echo ============================================================
echo   SOS Print Windows Agent - Setup for Shakeel Online Services
echo ============================================================
echo.
echo Checking for .NET 8 Windows Desktop Runtime...
dotnet --list-runtimes | findstr /i "Microsoft.WindowsDesktop.App 8." >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] .NET 8 Windows Desktop Runtime was not detected on this PC.
    echo Please download and install .NET 8 Desktop Runtime (x64) from:
    echo https://dotnet.microsoft.com/en-us/download/dotnet/8.0
    echo.
    echo Press any key to continue if already installed or to proceed anyway...
    pause >nul
) else (
    echo [OK] .NET 8 Desktop Runtime is detected!
)

set TARGET_DIR=%LOCALAPPDATA%\SOSPrintAgent
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo.
echo Copying agent files to %TARGET_DIR%...
xcopy /y /e /i "%~dp0*.*" "%TARGET_DIR%\" >nul

echo.
echo [SUCCESS] Agent files installed to %TARGET_DIR%
echo To start the agent and pair with your shop, run: start-agent.bat
echo.
pause
